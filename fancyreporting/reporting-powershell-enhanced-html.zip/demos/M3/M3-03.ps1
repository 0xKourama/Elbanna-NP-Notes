$PreContent1 = "<h1> This is Bios Info as a List </h1>"
$PreContent2 = "<h1> This is Bios Info as a Table </h1>"

$Bios = Get-WmiObject -class Win32_BIOS | Select PSComputerName, Manufacturer, BIOSVersion | ConvertTo-EnhancedHTMLFragment -As List -PreContent $PreContent1
$Bios2 = Get-WmiObject -class Win32_BIOS | Select PSComputerName, Manufacturer, BIOSVersion | ConvertTo-EnhancedHTMLFragment -As Table -PreContent $PreContent2
ConvertTo-EnhancedHTML -HTMLFragments  $Bios,$Bios2 -CssUri C:\Pluralsight\HTML\styles2.css | Out-File PreExample.html
