$PreContent1 = "<h1> This is Bios Info as a List </h1>"
$PreContent2 = "<h2> + This is Bios Info as a Table </h2>"

$Bios = Get-WmiObject -class Win32_BIOS | Select PSComputerName, Manufacturer, BIOSVersion | ConvertTo-EnhancedHTMLFragment -As List -PreContent $PreContent1

$Bios2 = Get-WmiObject -class Win32_BIOS | Select PSComputerName, Manufacturer, BIOSVersion | ConvertTo-EnhancedHTMLFragment -As Table -PreContent $PreContent2 -MakeHiddenSection

ConvertTo-EnhancedHTML -HTMLFragments  $Bios,$Bios2 -CssUri C:\Pluralsight\HTML\styles2.css | Out-File HiddenExample.html

