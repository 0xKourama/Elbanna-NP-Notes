$params = @{'As'='Table';
'PreContent'='<h2> All Services</h2>';
'MakeTableDynamic'=$true;
'TableCssClass'='grid';
'Properties'='Name','DisplayName', @{n='Service Status';e={$_.Status};css={if ($_.Status -eq "Stopped") { 'red' }}}}

$Services = Get-Service  | ConvertTo-EnhancedHTMLFragment @params
ConvertTo-EnhancedHTML -HTMLFragments $Services -CssUri C:\Pluralsight\HTML\styles2.css | Out-File paramexample.html