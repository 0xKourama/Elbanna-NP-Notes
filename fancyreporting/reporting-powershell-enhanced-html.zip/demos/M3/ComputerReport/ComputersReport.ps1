param([String[]] $Hosts)

function GetDiskInfo ($ComputerName) {
	$drives = Get-WmiObject -class Win32_LogicalDisk -Filter "DriveType=3" -ComputerName $ComputerName
	foreach ($drive in $drives) {
		$props = @{'Drive'=$drive.DeviceID;
		'Size'=$drive.size / 1GB -as [int];
		'Free'="{0:N2}" -f ($drive.freespace / 1GB);
		'FreePct'=$drive.freespace / $drive.size * 100 -as [int]}
		New-Object -TypeName PSObject -Property $props
	}
}

function GetBiosInfo ($ComputerName) {
	$os = Get-WmiObject -class Win32_OperatingSystem -ComputerName $ComputerName
	$props = @{'Computer Name'=$os.PSComputerName;
	'Manufacturer'=$os.Manufacturer;
	'Operating System' = $os.Caption;
	'BIOS Version'=$os.Version}
	New-Object -TypeName PSObject -Property $props
}

$Date = Get-Date -Format d
foreach ($hostname in $Hosts)
{
	Write-Host $hostname
	$params = @{'As'='Table';
	'PreContent'='<h2>Disk Information</h2>';
	'EvenRowCssClass'='even';
	'OddRowCssClass'='odd';
	'TableCssClass'='grid';
	'Properties'='Drive','Size', @{n='Free Percentage as %';e={$_.FreePct};css={if ($_.FreePct -lt "30") { 'red' }}}}

	$htmldiskinfo = GetDiskInfo $hostname | ConvertTo-EnhancedHTMLFragment @params

	$params = @{'As'='List';
	'PreContent'='<h2>Bios Information</h2>';
	'TableCssClass'='grid';
	}

	$biosinfo = GetBiosInfo $hostname | ConvertTo-EnhancedHTMLFragment @params

	$params = @{'As'='Table';
	'PreContent'='<h2> + Services to Investigate</h2>';
	'EvenRowCssClass'='even';
	'OddRowCssClass'='odd';
	'MakeTableDynamic'=$true;
	'MakeHiddenSection'=$true;
	'TableCssClass'='grid';
	'Properties'='Name','DisplayName','StartType', @{n='Service Status';e={$_.Status};css={if ($_.Status -eq "Stopped" -and $_.StartType -eq "Automatic" ) { 'red' }}}}

	$Services = Get-Service -ComputerName $hostname | Where {$_.Status -eq "Stopped" -and $_.StartType -eq "Automatic" } | ConvertTo-EnhancedHTMLFragment @params

	ConvertTo-EnhancedHTML -HTMLFragments $biosinfo, $htmldiskinfo, $Services -CssUri C:\Pluralsight\M3\ComputerReport\styles2.css -PreContent "<H1>Computer Report for $hostname on $date</H1>" | Out-File "$hostname.html"
}
