$Bios = Get-WmiObject -class Win32_BIOS | Select PSComputerName, Manufacturer, BIOSVersion |ConvertTo-EnhancedHTMLFragment -As List

$Bios2 = Get-WmiObject -class Win32_BIOS | Select PSComputerName, Manufacturer, BIOSVersion |ConvertTo-EnhancedHTMLFragment -As Table

ConvertTo-EnhancedHTML -HTMLFragments  $Bios,$Bios2 -CssUri C:\Pluralsight\HTML\styles2.css | Out-File AsExample.html