$Header = @"
<style>
table {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}
th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
<title>Report Title</title>
"@

$OS = Get-WmiObject -class Win32_OperatingSystem | ConvertTo-HTML -Fragment 
$Bios = Get-WmiObject -class Win32_BIOS | ConvertTo-HTML -Fragment 
$Services = Get-WmiObject -class Win32_Service | ConvertTo-HTML -Fragment 
ConvertTo-HTML -Body "$OS $Bios $Services"  -Head $Header | Out-File StatusReport.html
