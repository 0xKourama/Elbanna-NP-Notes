$OS = Get-WmiObject -class Win32_OperatingSystem | ConvertTo-HTML -Fragment 
$Bios = Get-WmiObject -class Win32_BIOS | ConvertTo-HTML -Fragment 
$Services = Get-WmiObject -class Win32_Service | ConvertTo-HTML -Fragment 
ConvertTo-HTML -Body "$OS $Bios $Services" -Title "Report" | Out-File MultiStatusReport.html
